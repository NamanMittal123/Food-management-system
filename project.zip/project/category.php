<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<title>category page</title>
<style type="text/css">
body{
	background:url(image/image5.jpg);
	background-size:100% 110%;
	background-repeat:no-repeat;
	height:87vh;
}

#head
{
	width:860px;
	height:80px;
	background-color:rgba(0,0,0,0.4);
	margin:0 auto;
	margin-top:30px;
	padding-top:5px;
	padding-left:80px;
	border-radius:15px;
	color:white;
	font-weight:bolder;
	box-shadow:inset -4px -4px rgba(0,0,0,0.5);
	font-size: 18px;
}
#bca1
{
	width:280px;
	height:380px;
	background-color:rgba(0,0,0,0.4);
	margin:0 auto;
	margin-top:20px;
	padding-top:5px;
	padding-left:30px;
	border-radius:15px;
	color:white;
	font-weight:bolder;
	box-shadow:inset -4px -4px rgba(0,0,0,0.5);
	font-size: 18px;
}
#bca2
{
	width:280px;
	height:380px;
	background-color:rgba(0,0,0,0.4);
	margin:0 auto;
	margin-top:20px;
	padding-top:5px;
	padding-left:40px;
	border-radius:15px;
	color:white;
	font-weight:bolder;
	box-shadow:inset -4px -4px rgba(0,0,0,0.5);
	font-size: 18px;
    
}
#bca3
{
	width:280px;
	height:380px;
	background-color:rgba(0,0,0,0.4);
	margin:0 auto;
	margin-top:20px;
	padding-top:5px;
	padding-left:40px;
	border-radius:15px;
	color:white;
	font-weight:bolder;
	box-shadow:inset -4px -4px rgba(0,0,0,0.5);
	font-size: 18px;
}

</style>

</head>

<body>
<div class="head">
<a href="logout.php"><h2>logout</h2></a>
<center><h1>CATEGORY</h1></center>
</div>

<table cellpadding="40px" align="center">
<tr><td>
<div id="bca1">
<center><h1> BCA 1ST YEAR</h1></center>
    <ul>
    <li><a href="#"><h3>teacher's notification</h3></a></li>
    <li><a href="#"><h3>time table</h3></a></li>
    <li><a href="#"><h3>fees structure</h3></a></li>
    <li><a href="#"><h3>syllabus</h3></a></li>
    <li><a href="#"><h3>workshops/seminaar</h3></a></li>
    <li><a href="#"><h3>Educational trips</h3></a></li>
    </ul></div></td>
<td><div id="bca2">
<center><h1>BCA 2ND YEAR</h1></center>
     <ul>
    <li><a href="#"><h3>teacher's notification</h3></a></li>
    <li><a href="#"><h3>time table</h3></a></li>
    <li><a href="#"><h3>fees structure</h3></a></li>
    <li><a href="#"><h3>syllabus</h3></a></li>
    <li><a href="#"><h3>workshops/seminaar</h3></a></li>
    <li><a href="#"><h3>Educational trips</h3></a></li>
    </ul></div></td>
<td><div id="bca3">
<center><h1>BCA 3RD YEAR</h1></center>
     <ul>
    <li><a href="#"><h3>teacher's notification</h3></a></li>
    <li><a href="#"><h3>time table</h3></a></li>
    <li><a href="#"><h3>fees structure</h3></a></li>
    <li><a href="#"><h3>syllabus</h3></a></li>
    <li><a href="#"><h3>workshops/seminaar</h3></a></li>
    <li><a href="#"><h3>Educational trips</h3></a></li>
    </ul></div></td></tr>
    
</table>
      
</body>
</html>