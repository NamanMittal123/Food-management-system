<?php session_start(); ?><!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<title>sign up page</title>
<style type="text/css">
body{
	background:url(image/image1.jpg);
	background-size:100% 137%;
	background-repeat:no-repeat;
	height:70vh;
}
#main{
	width:900px;
	height:450px;
	background-color:rgba(255,255,255,0.0);
	margin-left:140px;
	margin-top:88px;
	padding-top:0px;
	padding-left:20px;
	border-radius:15px;
	color:white;
	font-weight:bolder;
	font-size: 18px;
}

#main input[type="text"]{
	width:200px;
	height:20px;
	border:0;
	border-radius: 5px;
	padding-left:5px;
}
#main input[type="password"]{
	width:200px;
	height:25px;
	border:0;
	border-radius: 5px;
	padding-left:5px;
}
#main input[type="submit"]{
	width:100px;
	height:25px;
	border:0;
	border-radius: 5px;
	background-color:skyblue;
	font-weight:bolder;
}
#main input[type="button"]{
	width:100px;
	height:25px;
	border:0;
	border-radius: 5px;
	background-color:skyblue;
	font-weight:bolder;
}
#main input[type="radio"]{
	width:40px;
	height:15px;
	border:0;
	border-radius: 5px;
	background-color:skyblue;
	font-weight:bolder;
}


</style>

</head>

<body>
<div id="main">
<h1 style="color:#000">Sign Up</h1>
<form method="post" action="signupaction.php" enctype="multipart/form-data">
    <table style="color:#000">
   
    <tr><td>Name</td><td><input name="Name" type="text"/ placeholder="Name">
    <?php if(isset($_SESSION['error'][0]) && $_SESSION['error'][0]!="")
	{
		echo $_SESSION['error'][0];
		unset($_SESSION['error'][0]);
	}
	?></td></tr>
    <tr><td>Scholar_id</td><td><input name="Scholar_id" type="text"/ placeholder="Scholar number">
    <?php if(isset($_SESSION['error'][7]) && $_SESSION['error'][7]!="")
	{
		echo $_SESSION['error'][7];
		unset($_SESSION['error'][7]);
	}
	?></td></tr>
    <tr><td>Address</td><td><input name="Address" type="text"/ placeholder="Address">
    <?php if(isset($_SESSION['error'][8]) && $_SESSION['error'][8]!="")
	{
		echo $_SESSION['error'][8];
		unset($_SESSION['error'][8]);
	}?></td><tr>
    <tr><td>Contact_no</td><td><input name="Contact_no" type="text" placeholder="Contact number"/>
     <?php if(isset($_SESSION['error'][2]) && $_SESSION['error'][2]!="")
	{
		echo $_SESSION['error'][2];
		unset($_SESSION['error'][2]);
	}
	?>
	</td></tr>
    <tr><td>Category</td> <td>BCA1<input name="Category" type="radio" value="BCA1"/>
    BCA2<input name="Category" type="radio" value="BCA2" />
    BCA3<input name="Category" type="radio" value="BCA3" />
    <?php if(isset($_SESSION['error'][6])&& $_SESSION['error'][6]!="")
	{
		echo $_SESSION['error'][6];
		unset($_SESSION['error'][6]);
	}
	?></td></tr>
    <tr><td>Upload Image</td><td><input type="file" name="image"/>
     <?php if(isset($_SESSION['error'][1])&& $_SESSION['error'][1]!="")
	{
		echo $_SESSION['error'][1];
		unset($_SESSION['error'][1]);
	}
	?>
	</td></tr>
    <tr><td>Password</td><td><input name="Password" type="password" placeholder="Password"/>
    <?php if(isset($_SESSION['error'][3])&& $_SESSION['error'][3]!="")
	{
		echo $_SESSION['error'][3];
		unset($_SESSION['error'][3]);
	}
	?>
   <?php /*?> <?php if(isset($_SESSION['error'][5])&& $_SESSION['error'][5]!="")
	{
		echo $_SESSION['error'][5];
		unset($_SESSION['error'][5]);
	}
	?><?php */?></td></tr>
    <tr><td>Confirm_Password</td><td><input name="Confirm_Password" type="password" placeholder="Confirm Password"/>
     <?php if(isset($_SESSION['error'][4])&& $_SESSION['error'][4]!=" ")
	{
		echo $_SESSION['error'][4];
		unset($_SESSION['error'][4]);
	}?></td></tr><tr></tr><tr></tr><tr></tr><tr></tr><tr></tr><tr></tr><tr></tr><tr></tr><tr></tr><tr></tr><tr></tr><tr></tr><tr></tr><tr></tr><tr></tr>
    <tr><td><input name="SUBMIT" type="SUBMIT" value="SIGN UP" style="cursor:pointer; display:marker"/></td>
    <td><a href="index.php"><input name="button" value="CANCLE" type="button" style="cursor:pointer; display:marker" /> </a></tr>
    </table>
    <p style="color:#000"> already a member?<a href="login.php" style="color:#F00" >sign in</a></p>
</form>
</div>
</body>
</html>