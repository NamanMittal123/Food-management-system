<?php @session_start(); ?>
<html>
<head>
<title>profile</title>
<style>
*{
	margin:0px;
	padding:0px;
}
body{
	background:url(image/image5.jpg);
	background-size:100% 137%;
	background-repeat:no-repeat;
	height:70vh;
}
.box{
	width:300px;
	height:300px;
	background-color:rgba(0,0,0,0.3);
	margin:0 auto;
	margin-top:80px;
	padding-top:0px;
	padding-left:20px;
	border-radius:15px;
	color:white;
	font-weight:bolder;
	box-shadow:inset -4px -4px rgba(0,0,0,0.5);
	font-size: 18px;
}
.box table tr{
	color:white;
	font-size:14px;
	font-weight:bold;
}
</style>
</head>
<body>
<div class="box">
<?php
mysql_connect("localhost","root","");
mysql_select_db("projectphp");

$_SESSION['Scholar_id'];
$sql="select * from signup where Scholar_id='".$_SESSION['Scholar_id']."'";
$run=mysql_query($sql);

$data=mysql_fetch_array($run);
?>
<form method="post" action="update_action.php" enctype="multipart/form-data">
<center><h1> Update profile</h1>
<table>
<tr><td><img src="img/<?php echo $data['image'];?>" height="100" width="100"  /></td><td><input type="file" name="image"/></td></tr>
<tr><td>Name</td>
<td><input type="text" name="Name" value="<?php echo $data['Name'];?>"/>
<?php if (isset($_SESSION['error'][0]) && $_SESSION['error'][0]!="")
	{
		echo $_SESSION['error'][0];
		unset($_SESSION['error'][0]);
	}
	?></td></tr>
<tr><td>Scholar_id</td><td><input name="Scholar_id" type="text"/ placeholder="Scholar number" value="<?php echo $data['Scholar_id'];?>" readonly></td></tr>


    <tr><td>Address</td><td><input name="Address" type="text"/ placeholder="Address" value="<?php echo $data['Address'];?>"><br/>
    <?php if(isset($_SESSION['error'][2]) && $_SESSION['error'][2]!="")
	{
		echo $_SESSION['error'][2];
		unset($_SESSION['error'][2]);
	}?></td><tr>
    
    
    <tr><td>Contact_no</td><td><input name="Contact_no" type="text" placeholder="Contact number" value="<?php echo $data['Contact_no'];?>"/>
     <?php if(isset($_SESSION['error'][3]) && $_SESSION['error'][3]!="")
	{
		echo $_SESSION['error'][3];
		unset($_SESSION['error'][3]);
	}
	?>
	</td></tr>
    
    
    <tr><td>Category</td> <td>BCA1<input name="Category" type="radio" value="BCA1" <?php if($data['Category']=="BCA1"){echo "checked";}?>/>
    BCA2<input name="Category" type="radio"  value="BCA2"<?php if($data['Category']=="BCA2"){echo "checked";}?> />
    BCA3<input name="Category" type="radio" value="BCA3" <?php if($data['Category']=="BCA3"){echo "checked";}?> />
    <?php if(isset($_SESSION['error'][6])&& $_SESSION['error'][6]!="")
	{
		echo $_SESSION['error'][6];
		unset($_SESSION['error'][6]);
	}
	?></td></tr>
    
</tr>
<tr><td><input type="Submit" value="Submit"/>
</td>
</tr>
</table>
</center>
</form>
</div>
</body>
</html>              

