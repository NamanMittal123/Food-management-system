<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<title>abput us page</title>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<style type="text/css">
body{
	background:url(image/image5.jpg);
	background-size:100% 105%;
	background-repeat:no-repeat;
	height:93vh;
}
#head
{
	width:660px;
	height:80px;
	background-color:rgba(0,0,0,0.4);
	margin:0 auto;
	margin-top:20px;
	padding-top:5px;
	padding-left:60px;
	border-radius:15px;
	color:white;
	font-weight:bolder;
	box-shadow:inset -4px -4px rgba(0,0,0,0.5);
	font-size: 18px;
}
#main
{
	width:660px;
	height:480px;
	background-color:rgba(0,0,0,0.4);
	margin:0 auto;
	margin-top:20px;
	padding-top:5px;
	padding-left:30px;
	border-radius:15px;
	color:white;
	font-weight:bolder;
	box-shadow:inset -4px -4px rgba(0,0,0,0.5);
	font-size: 18px;
}
#main input[type="button"]{
	width:100px;
	height:25px;
	border:0;
	border-radius: 5px;
	background-color:skyblue;
	font-weight:bolder;
}

</style>

</head>

<body>
<div id="head">
<center><h1>ABOUT US</h1></center>
</div>

<div id="main"> 
<a href="index.php" style="font-size:larger; padding:0px" ><i class="fa fa-caret-left"></i></a> </div>
</body>
</html>