<?php @session_start();
mysql_connect("localhost","root","");
mysql_select_db("projectphp");
 $Name=$_REQUEST['Name'];
if($Name=="")
{
	$_SESSION['error'][0]="Please enter name";
	
}

$Scholar_id=$_REQUEST['Scholar_id'];

$Address=$_REQUEST['Address'];
if($Address=="")
{
	$_SESSION['error'][2]="please enter address";
	
}

$Contact_no=$_REQUEST['Contact_no'];
if(!preg_match("/^(?=.*[0-9]{10})/",$Contact_no))
{
	$_SESSION['error'][3]="please enter valid contact number";
	
}


$Category=$_REQUEST['Category'];
if(count($Category)!=1)
{
	$_SESSION['error'][6]="please choose atleast one column";
	 
}
if(isset($_FILES['image'])){
	$errors=array();
	$file_name=$_FILES['image']['name'];
	$file_size=$_FILES['image']['size'];
	$file_tmp=$_FILES['image']['tmp_name'];
	$file_type=$_FILES['image']['type'];
	$file_ext=strtolower(end(explode('.',$_FILES['image']['name'])));
	
	
	 $expensions=array("jpg","png","jpeg","gif","jfif","webp","tiff","raw","bmp"); 
	
	if(in_array($file_ext,$expensions)===false){
		$errors[]="extension not allowed,please choose a valid file format";
	}
	
	if($file_size> 2097152){
		$reeors[]="file size must be exactly 2 MB";
	}
	
	if(count($_SESSION['error'])>0){
		
@header("location:updateprofile.php");
	}
	else
	{ move_uploaded_file($file_tmp,'img/'.$file_name);
$sql="update signup set Name='".$Name."',Address='".$Address."',Contact_no='".$Contact_no."',Category='".$Category."',image='".$file_name."'where Scholar_id='".$_REQUEST['Scholar_id']."'"; 
if(mysql_query($sql))
 {
	 header("location:blank.php");
 }
 
	}
}
 ?>

</body>
</html>