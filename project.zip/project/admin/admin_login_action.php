<?php session_start(); 
mysql_connect("localhost","root","");
mysql_select_db("projectphp");
$Username=$_REQUEST['Username'];
$Password=$_REQUEST['Password'];
if($Username=="" or $Password=="")
{
	$_SESSION['error'][1]="Please enter username and password";
	header("location:admin_login.php");
}
else
{
$sql="select * from admin where Username='".$Username."' and Password='".$Password."'";
$run=mysql_query($sql);
if ($data=mysql_fetch_array($run))
{
	$_SESSION['Username']=$data['Username'];
	header("location:admin_home.php");
}
else
{
	$_SESSION['message']="Enter valid Username & password";
	header("location:admin_login.php");
}
 if(mysql_query($sql))
 {
	 echo "success";
 }
 else
 {
	 echo mysql_error();
 }
}
 
 ?>