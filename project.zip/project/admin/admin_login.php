<?php session_start(); ?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<title>login page</title>
<style type="text/css">
body{
	background:url(../image/aaron-burden-QJDzYT_K8Xg-unsplash.jpg);
	background-size:100% 150%;
	background-repeat:no-repeat;
	height:45vh;
}#main{
	width:300px;
	height:240px;
	background-color:rgba(102,153,204,0.5);
	margin:540px;;
	margin-top:150px;
	padding-top:5px;
	padding-left:50px;
	border-radius:15px;
	color:white;
	font-weight:bolder;
	box-shadow:inset -4px -4px rgba(102,153,255,0.3);
	font-size: 18px;
}

#main input[type="text"]{
	width:200px;
	height:25px;
	border:0;
	border-radius: 5px;
	padding-left:5px;
}
#main input[type="password"]{
	width:200px;
	height:25px;
	border:0;
	border-radius: 5px;
	padding-left:5px;
}
#main input[type="submit"]{
	width:100px;
	height:25px;
	border:0;
	border-radius: 5px;
	background-color:skyblue;
	font-weight:bolder;
}
#main input[type="button"]{
	width:100px;
	height:25px;
	border:0;
	border-radius: 5px;
	background-color:skyblue;
	font-weight:bolder;
}


</style>

</head>

<body>
<div id="main">
<h1>ADMIN</h1>
<form method="post" action="admin_login_action.php">

	<input type="text" placeholder="enter user name" name="Username" /><br /><br />
    <input type="password" placeholder="enter password" name="Password"/><br /><br />
     <?php if(isset($_SESSION['error'][1])&&($_SESSION['error'][1]!=""))
	{
		echo $_SESSION['error'][1];
		unset ($_SESSION['error'][1]);
	}
	?>
    <?php if(isset($_SESSION['message'])&&($_SESSION['message']!=""))
	{
		echo $_SESSION['message'];
		unset ($_SESSION['message']);
	}
	?>
    <table>
    <tr><td><input type="submit" value="GO" /></td><td></td><td></td><td><input type="button" value="BACK"/></td></tr>
    </table>
    
    
    
</form>
</div>
</body>
</html>