<?php session_start(); ?><!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Untitled Document</title>
<style>
*{
	margin:0px;
	padding:0px;
}
.main{
	width:370px;
	height:320px;
	background-color:rgba(153,153,153,0.8);
	box-shadow:inset -4px -4px rgba(204,204,204,0.4);
	margin:340px;
	margin-top:150px;
	padding-top:0px;
	padding-left:20px;
	border-radius:15px;
	font-weight:bolder;
	font-size: 18px;
	color:white;
}

</style>
<script type="text/javascript" language="javascript">
function click1(){
	alert("Message is starred");
}
</script>
</head>

<body background="../image/pexels-photo-998592.jpeg" style="background-size:180vh;background-repeat:no-repeat">
<div class="main">
<center>
 <form method="post" action="upload_action.php" enctype="multipart/form-data">
    <table>
    <h1> Add Notice</h1>
    <tr><td>Title Of Notice</td><td><input name="Title" type="text" placeholder="Title" /></td></tr>
	<tr><td></td><td><?php if(isset($_SESSION['error'][0]) && $_SESSION['error'][0]!="")
	{
		echo $_SESSION['error'][0];
		unset($_SESSION['error'][0]);
	}
	?></td></tr>
    <tr><td>Description</td><td><textarea name="Description" style="width:200px; height:80px;" placeholder="Text here" ></textarea>
    </td></tr>
	<tr><td></td><td>
     <?php if(isset($_SESSION['error'][1]) && $_SESSION['error'][1]!="")
	{
		echo $_SESSION['error'][1];
		unset($_SESSION['error'][1]);
	}
	?></td></tr>
    <tr><td>Image</td><td><input type="file" name="image" /></td></tr>
    <tr><td>Date of Upload</td><td><input type="date" name="Date"  /></td></tr>
    
    <tr><td><input name="Upload" type="SUBMIT" value="Upload"/></td>
    <td><a href="frame2.php"><input name="cancle" value="Back" type="button"/></a>
    &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
    <input value="Starred" type="button" onclick="click1()" /> </td> </tr>
 
    </table>
</form>
</center>
</div>
</body>
</html>
