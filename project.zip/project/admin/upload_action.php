<?php session_start();
mysql_connect("localhost","root","");
mysql_select_db("projectphp");

$Title=$_REQUEST['Title'];
if($Title=="")
{
	$_SESSION['error'][0]="please enter Title";
}
$Description=$_REQUEST['Description'];
if($Description=="")
{
	$_SESSION['error'][1]="please enter Description";
}

$Date=$_REQUEST['Date'];
if($Date=="")
{
	$_SESSION['error'][2]="please select date";
}
if(isset($_FILES['Image'])){
	
	$error=array();
	$file_name=$_FILES['Image']['name'];
	$file_size=$_FILES['Image']['size'];
	$file_tmp=$_FILES['Image']['tmp_name'];
	$file_type=$_FILES['Image']['type'];
	$file_ext=strtolower(end(explode('.',$_file_name)));
	$expensions=array("jpg","png","jpeg","gif","jfif","webp","tiff","raw","bmp"); 
	
	if(in_array($file_ext,$expensions)===false){
		$error[]="extension not allowed,please choose a valid file format";
	}
	
	if($file_size> 2097152){
		$error[]="file size must be exactly 2 MB";
	}
	if(empty($error)==true){
		move_uploaded_file($file_tmp."img/",$file_name);
	
}
}

if(count($_SESSION['error'])<1)
{

$sql="insert into notice( `Title`,`Description`,`Image`,`Date`) values ('".$Title."','".$Description."','".$file_name."','".$Date."')";
$query= mysql_query($sql);

if($query){
	$sql2="insert into starred( `Title`,`Description`,`Image`,`Date`) values ('".$Title."','".$Description."','".$file_name."','".$Date."')";
	$result=mysql_query($sql2);
}
 	if(mysql_query($sql2))
 
  	{
	 header("location:upload.php");
 	}
 	else
 	{
	 echo mysql_error();
 	}
}
else
{
	@header("location:upload.php");
}

?>
	
	
