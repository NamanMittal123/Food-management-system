<?php session_start();
mysql_connect("localhost","root","");
mysql_select_db("projectphp");

$Name=$_REQUEST['Name'];
if($Name=="")
{
	$_SESSION['error'][0]="Please enter name";
	
}
$Scholar_id=$_REQUEST['Scholar_id'];
$Address=$_REQUEST['Address'];
if($Address=="")
{
	$_SESSION['error'][2]="please enter address";
	
}
$Contact_no=$_REQUEST['Contact_no'];
if(!preg_match("/^(?=.*[0-9]{10})/",$Contact_no))
{
	$_SESSION['error'][3]="please enter valid contact number";
	
}

$Category=$_REQUEST['Category'];
if(count($Category)!=1)
{
	$_SESSION['error'][6]="please choose atleast one column";
	 
}
if(count($_SESSION['error'])<1){

$sql="update signup set Name='".$_REQUEST['Name']."',Scholar_id='".$_REQUEST['Scholar_id']."',Address='".$_REQUEST['Address']."',Contact_no='".$_REQUEST['Contact_no']."',Category='".$_REQUEST['Category']."'where id='".$_SESSION['id']."'"; 
if(mysql_query($sql))
 {
	 header("location:blank.php");
 }
else{
	mysql_error();
}
}
else{
	header("location:updateprofile.php");

}
 ?>
