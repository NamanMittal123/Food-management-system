<?php
mysql_connect("localhost","root","");
mysql_select_db("projectphp");
$sql="select * from notice where id='".$_REQUEST['id']."' ";
$run=mysql_query($sql);
$data=mysql_fetch_array($run);
?>

<html>
<body>
<center>
<h2>profile</h2>
<table>
<tr><td><img src="../img/<?php echo $data['Image'];?>" height="100" width="100"  /></td></tr>
<tr><td>Title </td><td>:</td><td><?php echo $data['Title'];?></td></tr>
<tr><td>Description </td><td>:</td><td><?php echo $data['Description'];?></td></tr>
</table>
</center>
</body>
</html>
