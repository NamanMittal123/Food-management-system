<?php
mysql_connect("localhost","root","");
mysql_select_db("projectphp");

$sql="select * from signup where status=1";
$run=mysql_query($sql);
?>

<html>
<head>
<title></title>
<style>
*{
	margin:0px;
	padding:0px;
}
.profile{
	height:100vh;
	width:100%;
	background-image:url(../image/bi.jpg);
	background-size:180vh;
	background-repeat:no-repeat;
}
</style>
</head>
<body>
<div class="profile">
<center><h1> view data</h1></center>
<table border="1px" style="color:#000">
<tr><th>Id</th><th> Name</th><th>Scholar id</th><th>Address</th><th>Contact</th><th>Category</th><th>View Profile</th><th>Update Profile</th><th>Delete</th></tr>
<?php while($data=mysql_fetch_array($run))
{ ?>
<tr><td><?php echo $data['id'];?></td>
<td><?php echo $data['Name'];?></td>
<td><?php echo $data['Scholar_id'];?></td>
<td><?php echo $data['Address'];?></td>
<td><?php echo $data['Contact_no'];?></td>
<td><?php echo $data['Category'];?></td>
<td><a href="viewprofile.php?id=<?php echo $data['id']; ?>"> View Profile</a></td>
<td><a href="updateprofile.php?id= <?php echo $data['id']; ?>"> edit Profile</a></td>
<td><a href="delete.php?id= <?php echo $data['id']; ?>"> delete</a></td>
</tr>
<?php } ?>
</table>
</div>
</body>
</html>