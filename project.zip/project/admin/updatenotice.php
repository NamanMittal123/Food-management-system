<html>
<head>
<title>update notice panel</title>
</head>
<body>
<?php @session_start();
mysql_connect("localhost","root","");
mysql_select_db("projectphp");

$sql="select * from notice where id='".$_REQUEST['id']."'";
$run=mysql_query($sql);

$data=mysql_fetch_array($run);
$_SESSION['id']=$_REQUEST['id'];

?>
<form method="post" action="updatenotice_action.php"enctype="multipart/form-data">
<center><h1> Update Notice Panel</h1>
<table>
<tr><td>Title</td>
<td><input type="text" name="Title" placeholder="Title" value="<?php echo $data['Title'];?>"/>
<?php if (isset($_SESSION['error'][0]) && $_SESSION['error'][0]!="")
	{
		echo $_SESSION['error'][0];
		unset($_SESSION['error'][0]);
	}
	?></td></tr>

<tr><td>Description</td>
<td><input name="Description" type="text"/ placeholder=" Description" value="<?php echo $data['Description'];?>" >
<?php if (isset($_SESSION['error'][1]) && $_SESSION['error'][1]!="")
	{
		echo $_SESSION['error'][1];
		unset($_SESSION['error'][1]);
	}
	?></td></tr>
    
<tr><td><input type="Submit" value="Submit"/>
</td>
</tr>
</table>
</center>
</form>
</body>
</html>              
