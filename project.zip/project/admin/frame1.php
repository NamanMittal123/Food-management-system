<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Untitled Document</title>
<style>
*{
	margin:0px;
	padding:0px;
}
.frame1{
	height:100vh;
	width:100%;
	background:url(../image/i5.jpg);
	background-repeat:no-repeat;
	background-size:130vh;
}
.frame1 ul li{
	font-family: 'montserrat', sans-serif;
	list-style:none;
	font-size:17px;
	color:white;
	font-weight:bold;
	line-height:50px;
	margin-left:50px;
}
.frame1 ul li a{
	text-decoration:none;
}
</style>
</head>

<body>
<div class="frame1">
<ul><li><a href="blank.php" target="a" style="color:#FFF"> profile </a></li>
<li><a href="upload.php" target="a" style="color:#FFF"> Add Notice</a></li>
<li><a href="starrednoticetable.php" style="color:#FFF" target="a"> Starred Notice</a></li>
<li><a href="noticetable.php" style="color:#FFF" target="a"> View Notice</a></li>
<li><a href="admin_logout.php" style="color:#FFF" target="_parent"> Logout</a></li>
</ul>
</div>
</body>
</html>