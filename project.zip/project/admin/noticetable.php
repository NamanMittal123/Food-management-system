<?php
mysql_connect("localhost","root","");
mysql_select_db("projectphp");

$sql="select * from notice where status=1";
$run=mysql_query($sql);
?>

<html>
<head>
<title></title>
<style>
*{
	margin:0px;
	padding:0px;
}
.profile{
	height:100vh;
	width:100%;
	background-image:url(../image/bi.jpg);
	background-size:180vh;
	background-repeat:no-repeat;
}
</style>
</head>
<body>
<div class="profile">
<center><h1> view data</h1></center>
<table border="1px">
<tr><th>Id</th><th> Title</th><th> Description</th><th>Image</th><th>View Profile</th><th>Update Profile</th><th>Delete</th></tr>
<?php while($data=mysql_fetch_array($run))
{ ?>
<tr><td><?php echo $data['id'];?></td>
<td><?php echo $data['Title'];?></td>
<td><?php echo $data['Description'];?></td>
<td><?php echo $data['Image'];?></td>
<td><a href="viewnotice.php?id=<?php echo $data['id']; ?>"> View Profile</a></td>
<td><a href="updatenotice.php?id= <?php echo $data['id']; ?>"> edit Profile</a></td>
<td><a href="delete.php?id= <?php echo $data['id']; ?>"> delete</a></td>
</tr>
<?php } ?>
</table>
</div>
</body>
</html>