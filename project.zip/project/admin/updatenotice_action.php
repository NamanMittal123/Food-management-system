 <?php @session_start();
mysql_connect("localhost","root","");
mysql_select_db("projectphp");
 $Title=$_REQUEST['Title'];
if($Title=="")
{
	$_SESSION['error'][0]="Please enter Title";
	
}

$Description=$_REQUEST['Description'];
if($Description=="")
{
	$_SESSION['error'][1]="Please enter Description";
	
}

if(isset($_FILES['Image'])){
	$errors=array();
	$file_name=$_FILES['Image']['name'];
	$file_size=$_FILES['Image']['size'];
	$file_tmp=$_FILES['Image']['tmp_name'];
	$file_type=$_FILES['Image']['type'];
	$file_ext=strtolower(end(explode('.',$_FILES['Image']['name'])));
	
	
	 $expensions=array("jpg","png","jpeg","gif","jfif","webp","tiff","raw","bmp"); 
	
	if(in_array($file_ext,$expensions)===false){
		$errors[]="extension not allowed,please choose a valid file format";
	}
	
	if($file_size> 2097152){
		$reeors[]="file size must be exactly 2 MB";
	}
	
	if(count($_SESSION['error'])>0){
		
@header("location:updatenotice.php");
	}
	else
	{ move_uploaded_file($file_tmp,'img/'.$file_name);
$sql="update notice set Title='".$Title."',Description='".$Description."',,Image='".$file_name."'where id='".$_SESSION['id']."'"; 
if(mysql_query($sql))
 {
	 header("location:noticetable.php");
 }
 
	}
}
 ?>

</body>
</html>