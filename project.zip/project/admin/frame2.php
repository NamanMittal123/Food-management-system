<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Untitled Document</title>
<style>
.frame2{
	height:600px;
	width:100%;
	background:url(../image/hdback.jpg);
	background-repeat:no-repeat;
	background-size:auto;
}
</style>
</head>

<body>
<div class="frame2"></div>
</body>
</html>