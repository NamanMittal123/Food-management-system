<?php
mysql_connect("localhost","root","");
mysql_select_db("projectphp");

$sql="update signup set status=0 where id='".$_REQUEST['id']."'";
if(mysql_query($sql)){
	header("location:blank.php");
}else{
	echo mysql_error();
}