<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Untitled Document</title>

<frameset cols="20%,*" border="noborder">
	<frame src="frame1.php" />
    <frame src="frame2.php" name="a"/>
</frameset><noframes></noframes>
</head>

<body>

</body>
</html>