<html>
<head>
<title> user profile</title>
<style>
*{
	margin:0px;
	padding:0px;
}
body{
	background:url(image/image5.jpg);
	background-size:100% 137%;
	background-repeat:no-repeat;
	height:70vh;
}
.box{
	width:300px;
	height:300px;
	background-color:rgba(0,0,0,0.3);
	margin:0 auto;
	margin-top:80px;
	padding-top:0px;
	padding-left:20px;
	border-radius:15px;
	color:white;
	font-weight:bolder;
	box-shadow:inset -4px -4px rgba(0,0,0,0.5);
	font-size: 18px;
}
.box table tr{
	color:white;
	font-size:14px;
	font-weight:bold;
}
</style>
</head>
<body><?php @session_start();
mysql_connect("localhost","root","");
mysql_select_db("projectphp");

 $sql="select * from signup where Scholar_id='".$_SESSION['Scholar_id']."'"; 
$run=mysql_query($sql);

$data=mysql_fetch_array($run);
?>
<div class="box">
<center><h1>User Profile</h1>
<table>
<tr><td><img src="img/<?php echo $data['image'];?>" height="100" width="100"  /></td></tr>
<tr><td>Name:</td><td><?php echo $data['Name'];?></td></tr>
<tr><td>Scholar id:</td><td><?php echo $data['Scholar_id'];?></td></tr>
<tr><td>Address:</td><td><?php echo $data['Address'];?></td></tr>
<tr><td>Contact number:</td><td><?php echo $data['Contact_no'];?></td></tr>
<tr><td>Category:</td><td><?php echo $data['Category'];?></td></tr>
<tr><td><button onClick="window.location.href='simple1.php'">Back</button></td>
<td><button onClick="window.location.href='updateprofile.php'">Update</button></td></tr>
</table>
</div>
</center>
</body>
</html>