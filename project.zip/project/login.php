<?php session_start(); ?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<title>login page</title>
<style type="text/css">
body{
	background:url(image/image1.jpg);
	background-size:100% 200%;
	background-repeat:no-repeat;
	height:35vh;
}
#main{
	width:300px;
	height:290px;
	background-color:rgba(255,255,255,0.0);
	margin-left:80px;
	margin-top:100px;
	padding-top:0px;
	padding-left:150px;
	border-radius:15px;
	color:white;
	font-weight:bolder;
	font-size: 18px;
}

#main input[type="text"]{
	width:200px;
	height:25px;
	border:0;
	border-radius: 5px;
	padding-left:5px;
}
#main input[type="password"]{
	width:200px;
	height:25px;
	border:0;
	border-radius: 5px;
	padding-left:5px;
}
#main input[type="submit"]{
	width:100px;
	height:25px;
	border:0;
	border-radius: 5px;
	background-color:skyblue;
	font-weight:bolder;
}
#main input[type="button"]{
	width:100px;
	height:25px;
	border:0;
	border-radius: 5px;
	background-color:skyblue;
	font-weight:bolder;
}


</style>

</head>

<body>
<div id="main">
<center><h1 style="color:#000">login</h1></center>
<form method="post" action="loginaction.php">

	<input name="Scholar_id" type="text" placeholder="please enter scholar no" /><br /><br />
    <input name="Password" type="password" placeholder="********" /><br /><br />
    <?php if(isset($_SESSION['error'][1])&&($_SESSION['error'][1]!=""))
	{
		echo $_SESSION['error'][1];
		unset ($_SESSION['error'][1]);
	}
	?>
    <?php if(isset($_SESSION['message'])&&($_SESSION['message']!=""))
	{
		echo $_SESSION['message'];
		unset ($_SESSION['message']);
	}
	?>
    
    <table>
    <tr><td><input type="submit" name="submit" value="LOGIN" /></td>
    <td><a href="index.php"><input type="button" value="BACK"/></a></td></tr>
    <tr><td><a href="#"> forgot password</a></tr>
    </table>
    <p style="color:#F00"> New student:<a href="signup.php"> Sign up</a></p>    
</form>
</div>
</body>
</html>