<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<title>contact us page</title>
<style type="text/css">
body{
	background:url(image/image5.jpg);
	background-size:100% 105%;
	background-repeat:no-repeat;
	height:100vh;
}

#head
{
	width:860px;
	height:80px;
	background-color:rgba(0,0,0,0.4);
	margin:0 auto;
	margin-top:20px;
	padding-top:5px;
	padding-left:80px;
	border-radius:15px;
	color:white;
	font-weight:bolder;
	box-shadow:inset -4px -4px rgba(0,0,0,0.5);
	font-size: 18px;
}
#c1
{
	width:260px;
	height:380px;
	background-color:rgba(0,0,0,0.4);
	margin:0 auto;
	margin-top:20px;
	padding-top:5px;
	padding-left:30px;
	border-radius:15px;
	color:#6FC;
	font-weight:bolder;
	box-shadow:inset -4px -4px rgba(0,0,0,0.5);
	font-size: 18px;
	text-decoration:inherit;
}
#c2
{
	width:260px;
	height:380px;
	background-color:rgba(0,0,0,0.4);
	margin:0 auto;
	margin-top:20px;
	padding-top:5px;
	padding-left:40px;
	border-radius:15px;
	color:#6FC;
	font-weight:bolder;
	box-shadow:inset -4px -4px rgba(0,0,0,0.5);
	font-size: 18px;
    
}
#c3
{
	width:260px;
	height:380px;
	background-color:rgba(0,0,0,0.4);
	margin:0 auto;
	margin-top:20px;
	padding-top:5px;
	padding-left:40px;
	border-radius:15px;
	color:#6FC;
	font-weight:bolder;
	box-shadow:inset -4px -4px rgba(0,0,0,0.5);
	font-size: 18px;
}
#c4
{
	width:260px;
	height:380px;
	background-color:rgba(0,0,0,0.4);
	margin:0 auto;
	margin-top:20px;
	padding-top:5px;
	padding-left:40px;
	border-radius:15px;
	color:#6FC;
	font-weight:bolder;
	box-shadow:inset -4px -4px rgba(0,0,0,0.5);
	font-size: 18px;
}

</style>

</head>

<body>
<div id="head">
<center><h1>CONTACT US</h1></center>
</div>
<table cellpadding="40px" align="center">
<tr><td><div id="c1">
<img src="image/jayantimaam.png" height="150px" width="150px"  />
 <div>Name:                 Dr. Jayanti Goyal
           Department:	        Computer Science
           Qualification:  M.Phil, M.Tech, M.Sc., MBA ,Ph.D.
           Teaching Experience:  14 years
           Phone no:          9828458172
</div></td>
<td><div id="c2">
<img src="image/rekhasharma.png" height="150px" width="150px"  /> 
<div>Name: 	Ms. Rekha Sharma
Department:	Computer Science
Qualification:	M.Tech, SET/SLET
Teaching Experience: 4 years
Phone no:  9785225747
</div>
</td>
<td><div id="c3">
<img src="image/neelammam.jpg" height="150px" width="150px"  />
<div>
Name: 	Ms. Neelam Sunda
Department:	Computer Science
Qualification:	MCA , NET
Teaching Experience:	3 years
Phone no:   9672484757
</div>
</div></td>
<td><div id="c4">
<img src="image/rajinimam.jpg" height="150px" width="150px"  />
<div>
Name: 	Ms. Rajni Gora
Department:	Computer Science
Qualification:	MCA, NET, SET
Teaching Experience:	2 years
Phone no:     9636243604
</div>
</div></td></tr>



</table>
</body>
</html>