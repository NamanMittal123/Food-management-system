<?php session_start();
mysql_connect("localhost","root","");
mysql_select_db("projectphp");
$Name=$_REQUEST['Name'];
if($Name=="")
{
	$_SESSION['error'][0]="please enter name";
}

$Scholar_id=$_REQUEST['Scholar_id'];
if(!preg_match("/^(?=.*[0-9]{4})(?=.*[0-9]{4})/",$Scholar_id))
{
	$_SESSION['error'][7]="please enter valid scholar number";
}
$Address=$_REQUEST['Address'];
if($Address=="")
{
	$_SESSION['error'][8]="please enter address";
}

$Contact_no=$_REQUEST['Contact_no'];
if(!preg_match("/^(?=.*[0-9]{10})/",$Contact_no))
{
	$_SESSION['error'][2]="please enter valid contact number";
}

$Category=$_REQUEST['Category'];
if(count($Category)!=1)
{
	$_SESSION['error'][6]="please choose atleast one column";
}

if(isset($_FILES['image'])){
	
	$error=array();
	$file_name=$_FILES['image']['name'];
	$file_size=$_FILES['image']['size'];
	$file_tmp=$_FILES['image']['tmp_name'];
	$file_type=$_FILES['image']['type'];
	$file_ext=strtolower(end(explode('.',$_file_name)));
	$expensions=array("jpg","png","jpeg","gif","jfif","webp","tiff","raw","bmp"); 
	
	if(in_array($file_ext,$expensions)===false){
		$error[]="extension not allowed,please choose a valid file format";
	}
	
	if($file_size> 2097152){
		$error[]="file size must be exactly 2 MB";
	}
	if(empty($error)==true){
		move_uploaded_file($file_tmp."img/",$file_name);
	
}
		
		
$Password=$_REQUEST['Password'];
if(strlen($Password)<8)
{
	$_SESSION['error'][3]="atleast 8 character required";
	@header("location:signup.php");
}
/*if($Password !=preg_match("/^(?=.*\d)(?=.*[A-Za-z])[0-9A-Za-z]/",$Password))
{
	$_SESSION['error'][5]="please choose strong password";
	@header("location:signup.php");
}*/


$Confirm_Password=$_REQUEST['Confirm_Password']; 
if($Password != $Confirm_Password)
{
	$_SESSION['error'][4]="something wents wrong";
	
}
if(count($_SESSION['error'])<1)
{
	
move_uploaded_file($file_tmp,'img/'.$file_name);
$sql="insert into signup( `Name`,`Scholar_id`,`Address`,`Contact_no`,`Category`,`image`,`Password`,`Confirm_Password`) values ('".$Name."','".$Scholar_id."','".$Address."','".$Contact_no."','".$Category."','".$file_name."','".$Password."','".$Confirm_Password."')";

 	if(mysql_query($sql))
 
  	{
	 header("location:login.php");
 	}
 	else
 	{
	 echo mysql_error();
 	}
	
}else
{
	@header("location:signup.php");
}
}
 ?>