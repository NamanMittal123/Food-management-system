<?php session_start(); 
mysql_connect("localhost","root","");
mysql_select_db("projectphp");
$Scholar_id=$_REQUEST['Scholar_id'];
$Password=$_REQUEST['Password'];
if($Scholar_id=="" or $Password=="")
{
	$_SESSION['error'][1]="Please enter scholarid and password";
	header("location:login.php");
}
else
{
$sql="select * from signup where Scholar_id='".$Scholar_id."' and Password='".$Password."'";
$run=mysql_query($sql);
if ($data=mysql_fetch_array($run))
{
	$_SESSION['Scholar_id']=$data['Scholar_id'];
	header("location:simple1.php");
}
else
{
	$_SESSION['message']="Enter valid scholar id & password";
	header("location:login.php");
}
 if(mysql_query($sql))
 {
	 echo "success";
 }
 else
 {
	 echo mysql_error();
 }
}
 
 ?>